package hw2;

import java.awt.Graphics2D;

public abstract class Shape
{
    public abstract void Draw(Graphics2D graphics);
}
