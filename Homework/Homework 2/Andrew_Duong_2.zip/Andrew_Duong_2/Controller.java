package hw2;

public class Controller
{
    private Model model = new Model();
    public Controller(Model model)
    {
        this.model = model;
    }
}
