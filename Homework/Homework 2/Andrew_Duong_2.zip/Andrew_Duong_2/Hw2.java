package hw2;

public class Hw2
{
    public static void main(String[] args)
    {
        Controller controller = new Controller();
        View view = new View(controller);
    }
}
