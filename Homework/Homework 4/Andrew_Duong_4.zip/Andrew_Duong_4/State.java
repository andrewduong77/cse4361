interface State
{
    public abstract void doAction(Context context);
}