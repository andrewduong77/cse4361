import java.awt.Graphics2D;

interface Shape
{
    public abstract void Draw(Graphics2D graphics);
}
